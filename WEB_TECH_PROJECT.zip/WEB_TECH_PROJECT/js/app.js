function app(){
    this.nameInput = document.getElementsByClassName('text-input');
    this.select=document.getElementsByTagName('select');
    this.listing=document.getElementById('listing');
    this.checkboxes=document.querySelectorAll('.price-filter input[type="checkbox"]');
    this.checkboxLabel=document.querySelector('.price-filter label');

    this.items =[ 
    {
        name : 'Apple iphone 11',
        rom : '128gb',
        ram : '4gb',
        color : 'Green',
        price : 49000,
        brand : 'iphone',
        imageUrl: 'phone1.png'

    },

    {
        name : 'One Plus',
        rom : '128gb',
        ram : '12gb',
        color : 'Cosmic gray',
        price : 70000,
        brand : 'oneplus',
        imageUrl: 'phone2.jpg'

    }
];

this.filters = {};


}

app.prototype.render = function(){
this.items.forEach((item) => {
    const {name,rom,ram,color,price} = item;
    const template = `<div class="row">
                        <div class="mobile-image">
                            <img src="images/phone1.png"/>
                        </div>
                        <div class="mobile-content">
                            <h3>
                                ${name} (${rom} ROM , ${ram} RAM , ${color})
                            </h3>
                            <h3>
                                INR ${price}
                            </h3>
                        </div>
                    </div>`;
                    const element = document.createElement('div');
                    
                    element.innerHTML = template;
                    this.listing.appendChild(element);
});

app.prototype.bindEvents = function()
{
    this.nameInput[0].addEventListener('change',(event)=>{
        this.filters.name=event.target.value;
        this.filterResults();

    });
    this.select[0].addEventListener('change',(event)=>{
        this.filters.brand=event.target.value;
        this.filterResults();

    });
    
    this.checkboxes.forEach((checkbox) => {
        checkbox.addEventListener('click',(event) => {
          

            if(!this.filters.price){
                this.filters.price = [];
            }
            this.filters.price.push(event.target.value);
            this.filterResults();

        });


    });

};

app.prototype.filterResults = function(){
    console.log(this.filters);
}
const instance = new app();
instance.render();
instance.bindEvents();